package com.gec.engine;

public class ClientTest {
	
	public static void main(String[] args) {
		ClientEngine C = new ClientEngine("CLIENT");
		C.startClient("127.0.0.1", 8080);
	}
}
