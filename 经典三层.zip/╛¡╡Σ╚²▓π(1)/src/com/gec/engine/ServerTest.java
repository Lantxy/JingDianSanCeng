package com.gec.engine;

public class ServerTest {
	
	public static void main(String[] args) {
		ServerEngine S = new ServerEngine("SERVER");
		S.startServer( 8080 );
	}

}
