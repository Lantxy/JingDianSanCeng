package com.gec.exceptions;

import java.io.IOException;

public class ReadException extends IOException {

}
