package com.gec.network;

import java.util.Scanner;

public class Transceiver 
	implements MsgCallback {
	
	//this: ��˭ "�շ���", ���� "Server", "Client"��
	//      new ˭����˭ ��
	private NetWork network = new NetWork( this );
	protected String title = "Transceiver";
	
	public Transceiver(String title){
		this.title = title;
	}
	protected NetWork getNetWork(){		
		return network;
	}
	protected void print(Object obj){		
		System.out.println("{"+ title+"} "+ obj );
	}

	@Override
	public void onCreatedServer(boolean ret) { }

	@Override
	public void onAccepted(String ip, int port) { }

	@Override
	public void onConnectEvent(boolean ret, 
			String socketKey){ }

	@Override
	public void onReceivedMsg(String socketKey,
			String content){ }
	
	@Override
	public void onReceivedFailed(
		String socketKey){ }
	
	

}
