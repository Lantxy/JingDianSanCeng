package com.gec.controller;

import java.util.Scanner;

public class TestMain {

	public static void main(String[] args) 
		throws InstantiationException,
		NoSuchMethodException {
		Scanner sc = new Scanner(System.in);
		System.out.println("{debug} �����û���������:");
		String line = sc.nextLine();
		String username = line.split(",")[0];
		String password = line.split(",")[1];
		
		String json = "{\"method\":\"login\","
				+ "\"control\":\"StaffController\","
				+ "\"username\":\""+ username +"\","
				+ "\"password\":\""+ password +"\"}";
		
		RequestDispatcher dip = new RequestDispatcher( null );
		//{ps} �������ع����Ƿ� OK
		dip.intercept( json, "xxxx" );
		
	}
	
	
}
