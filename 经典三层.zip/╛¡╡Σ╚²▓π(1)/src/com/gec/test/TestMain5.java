package com.gec.test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.gec.controller.StaffController;
import com.gec.model.Attendance;
import com.gec.model.Staff;
import com.gec.service.StaffService;
import com.gec.utils.SessoinFactory;

public class TestMain5 {
	public static void main(String[] args)
			throws Exception {
		ArrayList<Attendance> arr =new ArrayList<>();
		for(int i=0;i<2;i++) {
		Attendance a=new Attendance();
		a.setInStatus("123");
		arr.add(a);
		}
		System.out.println(arr);
	}
	
}
