package com.gec.test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

import com.gec.controller.StaffController;
import com.gec.model.Staff;
import com.gec.service.StaffService;
import com.gec.utils.SessoinFactory;

public class TestMain4 {
	public static void main(String[] args)
			throws Exception {

		//StaffController c = new StaffController();
		//String resp = c.login("andy", "123");
		//System.out.println("resp="+ resp);
		
		
		//{result:failed,cause:û�����Ա��}
		//String resp = c.login("andy1", "123");
		//System.out.println("resp="+ resp);
		
		//{result:failed,cause:��Ч������}
		//String resp = c.login("andy", "1234");
		//System.out.println("resp="+ resp);

	}
	
}
