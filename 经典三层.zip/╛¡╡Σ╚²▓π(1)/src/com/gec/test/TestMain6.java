package com.gec.test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

import com.gec.controller.ControllerFactroy;
import com.gec.controller.StaffController;
import com.gec.model.Staff;
import com.gec.service.StaffService;
import com.gec.utils.SessoinFactory;

public class TestMain6 {
	
	public static void main(String[] args)
			throws Exception {

//		Object c1 = ControllerFactroy.makeController
//				( "StaffController" );
//		System.out.println( c1 );
//		
		Object c2 = ControllerFactroy.makeController
				( "AttendanceController" );
		System.out.println( c2 );
		Object c4 = ControllerFactroy.makeController
				( "AttendanceController" );
		System.out.println( c4 );
		System.out.println( "c4 �� c2 �ǲ���ͬһ������:"+ (c2==c4) );
		
//		Object c3 = ControllerFactroy.makeController
//				( "UserController" );
//		System.out.println( c3 );
		
	}
	
}
