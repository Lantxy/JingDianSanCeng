package com.gec.test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

import com.gec.utils.SessoinFactory;

public class TestMain2 {
	public static void main(String[] args)
			throws Exception {
		TestClass c = new TestClass();
		new Thread(c,"�߳�A").start();
		
		Thread.sleep( 1000 );
		new Thread(c,"�߳�B").start();
	}
	
}

	class TestClass implements Runnable{
		@Override
		public void run() {
			Connection c;
			try {
				String thName = Thread.currentThread().getName();
				System.out.println("{��ǰ�߳�} name = "+ thName);
				c = SessoinFactory.openConnection();
				System.out.println( "{��ǰ����} conn = "+ c );
				
				Scanner sc = new Scanner(System.in);
				System.out.println( "Next ...." );
				sc.next();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	