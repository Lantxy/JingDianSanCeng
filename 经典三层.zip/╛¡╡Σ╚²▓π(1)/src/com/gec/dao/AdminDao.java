package com.gec.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.gec.model.Admin;
import com.gec.model.Attendance;
import com.gec.model.Staff;
import com.gec.utils.JdbcUtils;
import com.gec.utils.SessoinFactory;

public class AdminDao {

	//{ps} ��Ӧ�������д�κε� "ҵ���߼�"
	public Admin validateStaff( String username )
		throws SQLException
	{
		String sql = "select * from admin s where s.username=?";
		//{1} �õ�һ������ ? {����ض���ͬһ�߳�, ���ҵõ�����ͬһ������}
		//    {ps} �� StaffService ����������һ����
		//    {ps} �����ﲻ��ȥ "�ر�����", �� Service ���رա�
		Connection conn = SessoinFactory.openConnection();
		//{2} �����õ��ı���
		PreparedStatement pmst = null;
		ResultSet rs = null;
		Admin admin = null;
		//{2} ��ȡ sql ִ����
		pmst = conn.prepareStatement( sql );
		//{3} ����ռλ���ϵĲ���
		pmst.setString( 1, username );
		//{4} ִ�в�ѯ
		rs = pmst.executeQuery();
		//{5} �ж��Ƿ������ݷ���
		if( rs.next() ){  //{ps} �����ݷ���
			//{6} ��װ Staff ����, (ע��Model����)
			admin = new Admin( rs );
			System.out.println( "{DAO} admin = "+ admin );
		}
		//{6} �ر� RS, PSMT
		JdbcUtils.closeResultSet(pmst, rs);
		//{7} ���� Model ����
		return admin;
	}

	public boolean register(String id,String username, String password,String nickName,String position,String sex,String createDate)
			throws SQLException
		{
			String sql="insert into staff (id,username,password,nickName,position,sex,createDate) VALUES(?,?,?,?,?,?,?)";
			Connection conn = SessoinFactory.openConnection();
			PreparedStatement pmst = null;
			pmst = conn.prepareStatement( sql );
			pmst.setString( 1, id );
			pmst.setString( 2, username );
			pmst.setString( 3, password );
			pmst.setString( 4, nickName );
			pmst.setString( 5, position );
			pmst.setString( 6, sex );
			pmst.setString( 7, createDate );
			int rs = pmst.executeUpdate();
			pmst.close();
			return true;
		}
	
	public ArrayList<Staff> query()
			throws SQLException
		{
		ArrayList<Staff> arr = new ArrayList<>();
		String sql = "select * from staff";
		Connection conn = SessoinFactory.openConnection();
		PreparedStatement pmst = null;
		ResultSet rs = null;
		Staff staff = null;
		pmst = conn.prepareStatement( sql );
		rs = pmst.executeQuery();
		while( rs.next() ){
			staff = new Staff( rs );
			arr.add(staff);
		}
		JdbcUtils.closeResultSet(pmst, rs);
			return arr;
		}
	
	public ArrayList<Attendance> queryworkdata( String staffid,String data)
			throws SQLException
		{
			ResultSet rs;
			ArrayList<Attendance> arr=new ArrayList<>();
			String sql="select * from view_attd where staffId=? and workingDate like ?";
			Connection conn = SessoinFactory.openConnection();
			PreparedStatement pmst = null;
			pmst = conn.prepareStatement( sql );
			pmst.setString( 1, staffid );
			pmst.setString( 2, "%" +data +"%");
			rs = pmst.executeQuery();
			 while(rs.next()) {
				 Attendance a=new Attendance();
				 a.setWorkingDate(rs.getString(1));
				 a.setStaffId(rs.getString(2));
				 a.setNickName(rs.getString(3));
				 a.setInStatus(rs.getString(4));
				 a.setInTime(rs.getString(5));
				 a.setOutStatus(rs.getString(6));
				 a.setOutTime(rs.getString(7));
				 arr.add(a);
			 }
			 JdbcUtils.closeResultSet(pmst, rs);
			return arr;
		}
}
