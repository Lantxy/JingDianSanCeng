package com.gec.model;

import java.sql.ResultSet;
import java.sql.SQLException;

//Staff ��
//+------------+-----------------+
//| Field      | Type            |
//+------------+-----------------+
//| id         | int(11)         |
//| username   | varchar(32)     |
//| password   | varchar(32)     |
//| nickName   | varchar(32)     |
//| position   | varchar(64)     |
//| age        | int(11)         |
//| sex        | enum('��','Ů')  |
//| createDate | timestamp       |
//+------------+-----------------+
public class Staff {
	private String id;
	private String username;
	private String password;
	private String nickName;
	private String position;
	private int age;
	private String sex;
	private String createDate;
	
	public Staff( ) { }
	public Staff(ResultSet rs) throws SQLException {
		this.id = rs.getString("id");
		this.username = rs.getString("username");
		this.password = rs.getString("password");
		this.nickName = rs.getString("nickName");
		this.position = rs.getString("position");
		this.age = rs.getInt("age");
		this.sex = rs.getString("sex");
		this.createDate=rs.getString("createDate");
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	
	@Override
	public String toString() {
		return "Staff [id=" + id + ", username=" + 
				username + ", password=" + password + 
				", nickName=" + nickName +"]";
	}

}
