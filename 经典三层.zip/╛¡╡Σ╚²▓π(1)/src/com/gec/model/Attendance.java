package com.gec.model;

import java.sql.ResultSet;
import java.sql.SQLException;

//Staff ��
//+------------+-----------------+
//| Field      | Type            |
//+------------+-----------------+
//| id         | int(11)         |
//| username   | varchar(32)     |
//| password   | varchar(32)     |
//| nickName   | varchar(32)     |
//| position   | varchar(64)     |
//| age        | int(11)         |
//| sex        | enum('��','Ů')  |
//| createDate | timestamp       |
//+------------+-----------------+
public class Attendance {
	
	private String workingDate;
	private String staffId;
	private String nickName;
	private String inStatus;
	private String inTime;
	private String outStatus;
	private String outTime;
	
	public Attendance( ) { }
	public Attendance(ResultSet rs) throws SQLException {
		this.workingDate = rs.getString("workingDate");
		this.staffId = rs.getString("staffId");
		this.nickName = rs.getString("nickName");
		this.inStatus = rs.getString("inStatus");
		this.inTime = rs.getString("inTime");
		this.outStatus = rs.getString("outStatus");
		this.outTime = rs.getString("outTime");
	}
	public String getWorkingDate() {
		return workingDate;
	}
	public void setWorkingDate(String workingDate) {
		this.workingDate = workingDate;
	}
	public String getStaffId() {
		return staffId;
	}
	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getInStatus() {
		return inStatus;
	}
	public void setInStatus(String inStatus) {
		this.inStatus = inStatus;
	}
	public String getInTime() {
		return inTime;
	}
	public void setInTime(String inTime) {
		this.inTime = inTime;
	}
	public String getOutStatus() {
		return outStatus;
	}
	public void setOutStatus(String outStatus) {
		this.outStatus = outStatus;
	}
	public String getOutTime() {
		return outTime;
	}
	public void setOutTime(String outTime) {
		this.outTime = outTime;
	}
	@Override
	public String toString() {
		return "Attendance [workingDate=" + workingDate + ", staffId=" + staffId + ", nickName=" + nickName
				+ ", inStatus=" + inStatus + ", inTime=" + inTime + ", outStatus=" + outStatus + ", outTime=" + outTime
				+ "]";
	}
}
